function trocaCor(cor){
    let circulo =document.querySelector(".circulo")
    circulo.style.background = cor
}

function trocarImagem(imagem){
    let imgiphone = document.querySelector(".iphone")
    imgiphone.src = imagem
}